<?php
declare(strict_types=1);
require __DIR__.'/core.php';
require __DIR__.'/modules.php';
require __DIR__.'/actions.php';
try{db();}catch(Throwable $ex){error_log((string)$ex);http_response_code(503);exit('No se pudo conectar. Comprueba que MySQL esté iniciado en XAMPP y que la instalación esté completa.');}
if(!empty($_SESSION['uid'])&&($_SESSION['last']??0)<time()-3600){session_unset();flash('La sesión venció por inactividad. Ingresa de nuevo.','error');}
if(!empty($_SESSION['uid']))$_SESSION['last']=time();
$page=(string)($_GET['p']??'inicio');
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(($_POST['action']??'')==='login'){handleLogin();}
 if(!user())go('login');checkCsrf();
 if(($_POST['action']??'')==='logout'){audit('CIERRE_SESION','usuarios',user()['id']);session_unset();session_regenerate_id(true);go('login');}
 try{
  if(!isset($modules[$page]))throw new DomainException('Pantalla inválida.');
  db()->beginTransaction();mutate($page);db()->commit();flash('Operación guardada correctamente.');
 }catch(Throwable $ex){
  if(db()->inTransaction())db()->rollBack();
  if($ex instanceof DomainException)$msg=$ex->getMessage();
  elseif($ex instanceof PDOException && ($ex->errorInfo[0]??'')==='45000')$msg=$ex->errorInfo[2];
  elseif($ex instanceof PDOException && ($ex->errorInfo[1]??0)==1062)$msg='Ya existe un registro con esos datos. Revisa los números de documento, registro o recibo.';
  elseif($ex instanceof PDOException && ($ex->errorInfo[1]??0)==1406)$msg='Uno de los campos es demasiado largo.';
  elseif($ex instanceof PDOException && in_array($ex->errorInfo[1]??0,[1452,4025],true))$msg='Los datos no cumplen las relaciones o restricciones de la base. Revisa las selecciones.';
  else{$msg='No se pudo guardar. Revisa los datos o consulta el registro del servidor.';error_log((string)$ex);}
  $_SESSION['old']=['page'=>$page,'data'=>array_diff_key($_POST,array_flip(['csrf','password','actual','nueva','confirmacion']))];flash($msg,'error');
 }go($page);
}
$notice=$_SESSION['flash']??null;unset($_SESSION['flash']);
if(!user()){$page='login';}
elseif($page!=='inicio'&&!isset($modules[$page])){http_response_code(404);$page='inicio';}
elseif(!can($page)){http_response_code(403);$page='inicio';$notice=['No tienes acceso a esa pantalla.','error'];}
$title=$page==='inicio'?'Resumen general':($modules[$page]['title']??'Iniciar sesión');
function notice($n):void{if($n)echo '<div class="notice '.e($n[1]).'" role="status">'.e($n[0]).'</div>';}
function fields(array $spec,array $values=[]):void{
 foreach($spec as $key=>$field){[$label,$type]=$field;$required=$field[3]??true;$v=$values[$key]??'';
  echo '<label class="field"><span>'.e($label).($required?' <b aria-label="obligatorio">*</b>':'').'</span>';
  if(in_array($type,['select','enum'],true)){
   echo '<select name="'.e($key).'" '.($required?'required':'').'><option value="">Seleccionar…</option>';
   $opts=$type==='select'?optionRows($field[2]):array_map(fn($x)=>['id'=>$x,'label'=>$x],$field[2]);
   foreach($opts as $o)echo '<option value="'.e($o['id']).'" '.((string)$v===(string)$o['id']?'selected':'').'>'.e($o['label']).'</option>';echo '</select>';
  }else{
   $htmltype=$type==='decimal'?'number':$type;
   echo '<input name="'.e($key).'" type="'.e($htmltype).'" value="'.e($type==='password'?'':$v).'" '.($required?'required':'').' '.($type==='decimal'?'step="0.001" min="0"':($type==='number'?'step="1" min="0"':'')).' '.($type==='password'?'autocomplete="new-password"':'').'>';
  }echo '</label>';
 }
}
?><!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($title)?> · ITSC</title><link rel="icon" type="image/png" href="assets/logo-itsc-v2.png"><script src="assets/theme.js?v=1"></script><link rel="stylesheet" href="assets/style.css"><link rel="stylesheet" href="assets/institucional.css?v=2"><link rel="stylesheet" href="assets/identidad-v2.css?v=3"><link rel="stylesheet" href="assets/dark.css?v=1"><script src="assets/app.js?v=2" defer></script></head>
<body>
<?php if($page==='login'): ?>
<main class="login-shell">
 <section class="login-story"><a class="brand" href="index.php"><img class="institutional-logo" src="assets/logo-itsc-v2.png" alt="Logotipo del Instituto Tecnológico Santa Cruz" width="64" height="64"><span>TECNOLÓGICO<br><strong>SANTA CRUZ</strong></span></a><div class="story-copy"><span class="eyebrow">GESTIÓN ACADÉMICA</span><h1>El siguiente paso<br>empieza aquí.</h1><p>Una visión clara de la vida académica.<br>Estudiantes, aprendizaje y gestión en un solo lugar.</p><div class="story-stats"><div><strong>8</strong><span>carreras</span></div><div><strong>267</strong><span>materias</span></div><div><strong>01</strong><span>comunidad</span></div></div></div><small>Aplicación local de práctica · Datos ficticios</small></section>
 <section class="login-form"><div class="login-card"><div class="login-theme-bar"><button type="button" class="theme-toggle" id="theme-toggle" aria-pressed="false" aria-label="Cambiar a modo oscuro"><span data-theme-icon aria-hidden="true">☾</span><span data-theme-label>Modo oscuro</span></button></div><span class="eyebrow muted">BIENVENIDO</span><h2>Ingresa a tu espacio</h2><p class="subtle">Usa el acceso asignado por administración.</p><?php notice($notice);?><form method="post" action="index.php?p=login"><?php token();?><input type="hidden" name="action" value="login"><label class="field"><span>Usuario</span><input name="usuario" autocomplete="username" required autofocus maxlength="60"></label><label class="field"><span>Contraseña</span><input name="password" type="password" autocomplete="current-password" required></label><button class="button full" type="submit">Ingresar <span>→</span></button></form><p class="login-help">¿Necesitas acceso? Solicítalo al administrador del sistema.</p><div class="demo-note"><span class="dot"></span> Entorno de práctica en XAMPP</div></div></section>
</main>
<?php else: ?>
<aside class="sidebar"><a class="brand" href="index.php"><img class="institutional-logo" src="assets/logo-itsc-v2.png" alt="Logotipo del Instituto Tecnológico Santa Cruz" width="64" height="64"><span>TECNOLÓGICO<br><strong>SANTA CRUZ</strong></span></a><div class="workspace-label"><span class="dot"></span> Gestión académica</div><nav aria-label="Navegación principal">
<?php $groups=['PRINCIPAL'=>['inicio'=>'Resumen','estudiantes'=>'Estudiantes','docentes'=>'Docentes','catalogo'=>'Carreras y materias'], 'GESTIÓN ACADÉMICA'=>['periodos'=>'Períodos','ofertas'=>'Ofertas de materias','matriculas'=>'Matrículas','inscripciones'=>'Inscribir materias','evaluaciones'=>'Evaluaciones','notas'=>'Calificaciones','sesiones'=>'Sesiones de clase','asistencias'=>'Asistencia','excepciones'=>'Justificaciones','cierres'=>'Cierre académico','recuperaciones'=>'Recuperaciones','boletin'=>'Boletín'], 'ADMINISTRACIÓN'=>['cargos'=>'Cargos','pagos'=>'Pagos','saldos'=>'Saldos','documentos'=>'Documentos','tramites'=>'Trámites','pasantias'=>'Pasantías','usuarios'=>'Usuarios','auditoria'=>'Actividad']];
foreach($groups as $group=>$links){$visible=array_filter($links,fn($label,$key)=>can($key),ARRAY_FILTER_USE_BOTH);if(!$visible)continue;echo '<div class="nav-group">'.e($group).'</div>';foreach($visible as $key=>$label)echo '<a class="nav-link '.($page===$key?'active':'').'" href="index.php?p='.e($key).'">'.e($label).($page===$key?'<span>↗</span>':'').'</a>';}
?></nav><div class="sidebar-footer"><span class="avatar"><?=e(substr(user()['nombre'],0,1))?></span><div><strong><?=e(user()['nombre'])?></strong><small><?=e(user()['rol'])?></small></div><a href="index.php?p=cuenta" title="Cambiar contraseña" aria-label="Cambiar contraseña">⚙</a></div></aside>
<div class="app-shell"><header class="topbar"><span>Instituto Tecnológico Santa Cruz <span class="divider">/</span> <strong><?=e($title)?></strong></span><div class="top-actions"><button type="button" class="theme-toggle" id="theme-toggle" aria-pressed="false" aria-label="Cambiar a modo oscuro"><span data-theme-icon aria-hidden="true">☾</span><span data-theme-label>Modo oscuro</span></button><span class="pill">XAMPP · local</span><a class="text-button" href="index.php?p=cuenta">Mi cuenta</a><form method="post"><?php token();?><input type="hidden" name="action" value="logout"><button class="text-button">Salir ↗</button></form></div></header>
<main class="content"><div class="page-heading"><div><div class="eyebrow muted"><?=e(date('d.m.Y'))?> <span> / </span> PORTAL ACADÉMICO</div><h1><?=e($title)?></h1><p class="subtle"><?=e($page==='inicio'?'Lo que necesitas saber, en un solo vistazo.':$modules[$page]['desc'])?></p></div><?php if($page==='boletin'):?><button type="button" class="button secondary" id="print-button">Imprimir boletín</button><?php endif;?></div>
<?php notice($notice); ?>
<?php if($page==='inicio'):
 [$f,$a]=offerFilter();$teacher=user()['rol']==='DOCENTE';
 $countOffers=(int)query("SELECT COUNT(*) FROM ofertas o WHERE 1=1 $f",$a)->fetchColumn();
 $countStudents=$teacher?(int)query("SELECT COUNT(DISTINCT mt.estudiante_id) FROM inscripciones i JOIN ofertas o ON o.id=i.oferta_id JOIN matriculas mt ON mt.id=i.matricula_id WHERE 1=1 $f",$a)->fetchColumn():(int)query('SELECT COUNT(*) FROM estudiantes')->fetchColumn();
 $countResults=(int)query("SELECT COUNT(*) FROM resultados_finales r JOIN inscripciones i ON i.id=r.inscripcion_id JOIN ofertas o ON o.id=i.oferta_id WHERE 1=1 $f",$a)->fetchColumn();
 ?>
 <section class="welcome-banner"><div><span class="eyebrow">APRENDER. CRECER. CONSTRUIR.</span><h2>Un nuevo día para<br>seguir avanzando.</h2><p>Bienvenido, <?=e(explode(' ',user()['nombre'])[0])?>. Tu espacio de trabajo está listo.</p></div><div class="banner-art"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><img class="banner-logo" src="assets/logo-itsc-v2.png" alt="Nuevo logotipo del Instituto Tecnológico Santa Cruz" width="158" height="158"></div></section>
 <section class="stats-grid" aria-label="Resumen"><article class="stat"><span>Estudiantes <?=$teacher?'asignados':'registrados'?></span><strong><?=$countStudents?></strong><small>Comunidad estudiantil</small></article><article class="stat"><span>Ofertas de materias</span><strong><?=$countOffers?></strong><small>Materias abiertas por paralelo</small></article><article class="stat"><span>Resultados calculados</span><strong><?=$countResults?></strong><small>Cierres registrados</small></article><article class="stat accent"><span>Carreras del instituto</span><strong>08</strong><small>Formación técnica superior</small></article></section>
 <div class="dashboard-columns"><section class="panel"><div class="panel-heading"><div><span class="eyebrow muted">TU DÍA A DÍA</span><h2>Accesos rápidos</h2></div><span>↗</span></div><div class="quick-grid"><?php foreach(['estudiantes'=>['01','Registrar estudiantes','Datos personales y contacto'], 'notas'=>['02','Cargar calificaciones','Práctica y teoría por evaluación'],'asistencias'=>['03','Registrar asistencia','Minutos efectivos por sesión'],'pagos'=>['04','Registrar un pago','Recibos y saldos pendientes']] as $key=>$v)if(can($key))echo '<a class="quick-card quick-'.e($key).'" href="index.php?p='.$key.'"><span class="quick-number">'.$v[0].'</span><h3>'.$v[1].' <span>↗</span></h3><p>'.$v[2].'</p></a>';?></div></section><section class="panel rules-card"><span class="eyebrow muted">REGLAS DE EVALUACIÓN</span><h2>Un criterio claro<br>para cada resultado.</h2><div class="rule"><strong>70 / 30</strong><span>Práctica y teoría</span></div><div class="rule"><strong>61 pts</strong><span>Nota mínima de aprobación</span></div><div class="rule"><strong>80 %</strong><span>Asistencia mínima</span></div><small>Parámetros aplicados de la R.M. 0189/2023. Excepciones documentadas por administración.</small></section></div>
 <div class="footnote">Aplicación de práctica con datos ficticios. Las tarifas y los prerrequisitos oficiales siguen pendientes de validación.</div>
<?php else:
 $spec=$modules[$page];$old=$_SESSION['old']??null;unset($_SESSION['old']);$values=$old&&$old['page']===$page?$old['data']:[];
 $edit=null;if(isset($_GET['edit'])&&in_array($page,['estudiantes','docentes','tramites','pasantias'],true)&&can($page,true)){$edit=one("SELECT * FROM $page WHERE id=?",[(int)$_GET['edit']]);if($edit)$values=$edit;}
 ?>
 <?php if($spec['fields']&&can($page,true)): ?>
 <details class="panel form-panel" <?=($page==='cuenta'||$edit||($old&&$old['page']===$page))?'open':''?>><summary><span><span class="plus">＋</span> <?=e($edit?'Editar registro #'.$edit['id']:($page==='cuenta'?'Cambiar contraseña':($page==='notas'||$page==='asistencias'||$page==='documentos'?'Registrar o actualizar':'Nuevo registro')))?></span><span class="summary-hint">Abrir formulario</span></summary><form method="post" class="entry-form"><?php token();?><input type="hidden" name="action" value="save"><?php if($edit):?><input type="hidden" name="record_id" value="<?=e($edit['id'])?>"><?php endif;?><div class="form-grid"><?php fields($spec['fields'],$values);?></div><div class="form-footer"><span>* Campos obligatorios</span><button class="button" type="submit">Guardar <?=e($page==='cierres'?'cierre':'registro')?> <span>→</span></button></div></form></details>
 <?php endif; ?>
 <?php if($page==='cierres'&&can($page,true)):?><section class="panel"><h2>Calcular resultado de una inscripción</h2><p class="subtle">La oferta debe tener un cierre de carga horaria. El resultado quedará registrado como una instantánea.</p><form method="post" class="inline-form"><?php token();?><input type="hidden" name="action" value="resultado"><?php fields(['inscripcion_id'=>['Inscripción','select','inscripciones']]);?><button class="button">Calcular resultado →</button></form></section><?php endif;?>
 <?php if($page!=='cuenta'):$data=listData($page); ?>
 <section class="panel records-panel"><div class="panel-heading"><div><span class="eyebrow muted">REGISTROS</span><h2><?=e($title)?> <span class="count"><?=count($data)?></span></h2></div><label class="search"><span aria-hidden="true">⌕</span><input type="search" id="table-search" placeholder="Buscar en los registros…" aria-label="Buscar registros"></label></div><?php table($data);?><div id="search-empty" class="empty" hidden>No hay coincidencias con esa búsqueda.</div><div class="table-footer">Hasta 1.000 registros recientes · La búsqueda filtra esta lista.</div></section>
 <?php if(in_array($page,['estudiantes','docentes','tramites','pasantias'],true)&&can($page,true)&&$data):?><section class="panel compact-panel"><h3>Editar un registro</h3><form method="get" class="inline-form"><input type="hidden" name="p" value="<?=e($page)?>"><label class="field"><span>Registro</span><select name="edit" required><option value="">Seleccionar…</option><?php foreach($data as $r):?><option value="<?=e($r['id'])?>">#<?=e($r['id'])?> · <?=e($r['nombres']??$r['tipo']??$r['empresa']??'')?></option><?php endforeach;?></select></label><button class="button secondary">Abrir para editar</button></form></section><?php endif;?>
 <?php if($page==='usuarios'):?><section class="panel compact-panel"><h3>Habilitar o deshabilitar acceso</h3><form method="post" class="inline-form"><?php token();?><input type="hidden" name="action" value="toggle"><label class="field"><span>ID de usuario</span><input type="number" min="1" name="id" required></label><button class="button secondary">Cambiar estado</button></form></section><?php endif;?>
 <?php endif; ?>
<?php endif; ?>
</main><footer class="app-footer"><span>ITSC · Gestión académica</span><span>Aplicación local · Versión 1.3</span></footer></div>
<?php endif; ?></body></html>
