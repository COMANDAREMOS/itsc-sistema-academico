const search=document.querySelector('#table-search');
if(search){search.addEventListener('input',()=>{const q=search.value.toLocaleLowerCase('es');let visible=0;document.querySelectorAll('tbody tr').forEach(row=>{const show=row.textContent.toLocaleLowerCase('es').includes(q);row.hidden=!show;if(show)visible++;});document.querySelector('#search-empty').hidden=visible>0;});}
document.querySelector('#print-button')?.addEventListener('click',()=>window.print());

const themeButton=document.querySelector('#theme-toggle');
function showThemeState(){
  if(!themeButton)return;
  const dark=document.documentElement.dataset.theme==='dark';
  themeButton.setAttribute('aria-pressed',String(dark));
  themeButton.setAttribute('aria-label',dark?'Cambiar a modo claro':'Cambiar a modo oscuro');
  themeButton.title=dark?'Cambiar a modo claro':'Cambiar a modo oscuro';
  themeButton.querySelector('[data-theme-icon]').textContent=dark?'☀':'☾';
  themeButton.querySelector('[data-theme-label]').textContent=dark?'Modo claro':'Modo oscuro';
}
themeButton?.addEventListener('click',()=>{
  const theme=document.documentElement.dataset.theme==='dark'?'light':'dark';
  document.documentElement.dataset.theme=theme;
  try{localStorage.setItem('itsc.theme',theme);}catch(_){}
  showThemeState();
});
window.addEventListener('storage',event=>{
  if(event.key==='itsc.theme'){
    document.documentElement.dataset.theme=event.newValue==='dark'?'dark':'light';
    showThemeState();
  }
});
showThemeState();
